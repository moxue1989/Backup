package test.exercise11android;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by 750118 on 3/3/2017.
 */

// Recycler view adapter
public class AgentAdapter extends RecyclerView.Adapter<AgentAdapter.ViewHolder>{

    private ArrayList<Agent> agents;

    public static class ViewHolder extends RecyclerView.ViewHolder{
        public TextView mTextView;
        public ViewHolder(View itemView) {
            super(itemView);
            mTextView = (TextView) itemView;
        }
    }

    public AgentAdapter(ArrayList<Agent> agents) {
        this.agents = agents;
    }

    @Override
    public AgentAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        // attach OnClickListener to each view holder
        TextView v = (TextView) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.textview_agent, parent, false);
        v.setOnClickListener(new MyOnClickListener());
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(AgentAdapter.ViewHolder holder, int position) {

        Agent agent = agents.get(position);
        holder.mTextView.setText(agent.toString());
    }

    @Override
    public int getItemCount() {
        return agents.size();
    }

    // display selected agent info
    private class MyOnClickListener implements View.OnClickListener {
        @Override
            public void onClick(View v) {
            TextView view = (TextView) v;
            RecyclerView rv = (RecyclerView)v.getParent();
            int pos = rv.getChildAdapterPosition(view);

            Context c = v.getContext();
            Intent intent = new Intent(c, AgentDetailsActivity.class);
            intent.putExtra("AgentId", pos);

            c.startActivity(intent);
        }
    }
}
