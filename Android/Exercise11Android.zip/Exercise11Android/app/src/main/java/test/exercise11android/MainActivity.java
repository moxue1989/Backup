package test.exercise11android;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuInflater;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends Activity{

    // declare recycle view
    private RecyclerView rvAgents;
    private RecyclerView.Adapter rvAdapter;
    private RecyclerView.LayoutManager rvLayoutManager;
    public static ArrayList<Agent> agents = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DBAccess db = new DBAccess(this);

        // create fake list of agents
        //agents = new ArrayList<Agent>();
//        for (int i = 0; i < 30; i++){
//            Agent agent = new Agent();
//            agent.setAgentId(i);
//            agent.setAgtFirstName("Agent" + i);
//            agent.setAgtLastName("LastName" + i);
//            agent.setAgtBusPhone("403" + i + i + i + i + i + i + i);
//            agent.setAgtEmail("Agent" + i + "@TravelExperts.com");
//            //agents.add(agent);
//            db.addAgent(agent);
//        }
//        agents = db.GetAgents();
        new AgentTask().execute();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option_menu, menu); //your file name
        return super.onCreateOptionsMenu(menu);
    }

    public class AgentTask extends AsyncTask<String,Integer,Agent[]> {

        @Override
        protected Agent[] doInBackground(String... params) {
            try {
                    URL url = new URL("https://travel-experts.appspot.com/api/agents");
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    BufferedReader rd = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder responseStrBuilder = new StringBuilder();
                    String inputStr;
                    while ((inputStr = rd.readLine()) != null){
                        responseStrBuilder.append(inputStr);
                    }
                    String jsonStr = responseStrBuilder.toString();
                    Gson gson = new Gson();
                    Agent[] agents = gson.fromJson(jsonStr, Agent[].class);
                    connection.disconnect();
                    return agents;

            } catch (Exception e){
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Agent[] result) {
            MakeToast(result.length+"");
            agents = new ArrayList<Agent>(Arrays.asList(result));
            LoadAgents();
        }
    }

    public void MakeToast(String toast){
        Toast.makeText(this,toast,Toast.LENGTH_LONG).show();
    }

    // load agent method
    private void LoadAgents(){
        rvAdapter = new AgentAdapter(agents);
        rvAgents.setAdapter(rvAdapter);
    }

    @Override
    protected void onStart() {
        // load agents into recycler view
        super.onStart();
        rvAgents = (RecyclerView) findViewById(R.id.rvAgentList);
        rvAgents.setHasFixedSize(true);
        rvLayoutManager = new LinearLayoutManager(this);
        rvAgents.setLayoutManager(rvLayoutManager);
        //LoadAgents();
    }
}
