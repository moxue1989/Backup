package test.exercise11android;

/**
 * Created by 750118 on 3/6/2017.
 */

public class Agent {

    private int agentId;

    private int agencyId;

    private String agtBusPhone;

    private String agtEmail;

    private String agtFirstName;

    private String agtLastName;

    private String agtMiddleInitial;

    public int getAgentId() {
        return agentId;
    }

    public String getAgtBusPhone() {
        return agtBusPhone;
    }

    public void setAgtBusPhone(String agtBusPhone) {
        this.agtBusPhone = agtBusPhone;
    }

    public String getAgtEmail() { return agtEmail; }

    public void setAgtEmail(String agtEmail) {
        this.agtEmail = agtEmail;
    }

    public String getAgtFirstName() {
        return agtFirstName;
    }

    public void setAgtFirstName(String agtFirstName) {
        this.agtFirstName = agtFirstName;
    }

    public String getAgtLastName() {
        return agtLastName;
    }

    public void setAgtLastName(String agtLastName) {
        this.agtLastName = agtLastName;
    }

    public String getAgtMiddleInitial() {
        return agtMiddleInitial;
    }

    public void setAgtMiddleInitial(String agtMiddleInitial) {
        this.agtMiddleInitial = agtMiddleInitial;
    }

    public String getAgtPosition() {
        return agtPosition;
    }

    public void setAgtPosition(String agtPosition) {
        this.agtPosition = agtPosition;
    }

    public void setAgentId(int agentId) {
        this.agentId = agentId;
    }

    private String agtPosition;

    public Agent() {
    }

    @Override
    public String toString() {
        return agtFirstName + " " + agtLastName;
    }
}
