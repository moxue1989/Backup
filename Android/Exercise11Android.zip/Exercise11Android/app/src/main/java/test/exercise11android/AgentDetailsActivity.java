package test.exercise11android;
import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

// display agent details for selected agent
public class AgentDetailsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
    }

    @Override
    protected void onStart() {
        // get agentId from extras in intent
        super.onStart();
        Bundle extras = getIntent().getExtras();
        int agentId = -1;
        if (extras != null){
            agentId = extras.getInt("AgentId");
        }
        Agent agent = MainActivity.agents.get(agentId);

        Toast.makeText(this, agent.toString(), Toast.LENGTH_SHORT).show();

        // load text boxes with agent details
        TextView tvFN = (TextView) findViewById(R.id.tvFirstName);
        TextView tvLN = (TextView) findViewById(R.id.tvLastName);
        TextView tvPhone = (TextView) findViewById(R.id.tvPhone);
        TextView tvEmail = (TextView) findViewById(R.id.tvEmail);

        tvFN.setText(agent.getAgtFirstName());
        tvLN.setText(agent.getAgtLastName());
        tvPhone.setText(agent.getAgtBusPhone());
        tvEmail.setText(agent.getAgtEmail());
    }
}
