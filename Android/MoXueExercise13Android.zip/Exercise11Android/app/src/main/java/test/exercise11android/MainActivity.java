package test.exercise11android;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import java.util.ArrayList;

public class MainActivity extends Activity {

    // declare recycle view
    private RecyclerView rvAgents;
    private RecyclerView.Adapter rvAdapter;
    private RecyclerView.LayoutManager rvLayoutManager;
    public static ArrayList<Agent> agents = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        DBAccess db = new DBAccess(this);
        // create fake list of agents
        //agents = new ArrayList<Agent>();
        for (int i = 0; i < 30; i++){
            Agent agent = new Agent();
            agent.setAgentId(i);
            agent.setAgtFirstName("Agent" + i);
            agent.setAgtLastName("LastName" + i);
            agent.setAgtBusPhone("403" + i + i + i + i + i + i + i);
            agent.setAgtEmail("Agent" + i + "@TravelExperts.com");
            //agents.add(agent);
            db.addAgent(agent);
        }

        agents = db.GetAgents();
    }

    // load agent method
    private void LoadAgents(){
        rvAdapter = new AgentAdapter(agents);
        rvAgents.setAdapter(rvAdapter);
    }

    @Override
    protected void onStart() {
        // load agents into recycler view
        super.onStart();
        rvAgents = (RecyclerView) findViewById(R.id.rvAgentList);
        rvAgents.setHasFixedSize(true);
        rvLayoutManager = new LinearLayoutManager(this);
        rvAgents.setLayoutManager(rvLayoutManager);
        LoadAgents();
    }
}
